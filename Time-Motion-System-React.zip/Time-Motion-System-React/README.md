# Time Motion System — React version

This is a Vite + React conversion of the uploaded Time Motion System HTML.

## Run locally

1. Install Node.js (18 or newer).
2. Extract this folder.
3. Open a terminal in this folder and run:

   ```bash
   npm install
   npm run dev
   ```

4. Open the local URL printed by Vite (usually http://localhost:5173).

## Included
- Employee name and ID saved in localStorage
- Live clock and running activity timer (elapsed time uses timestamps and survives reloads)
- Activity buttons, quick connected/non-connect counters, automatic break/lunch entries and break alert
- Editable activity table, time stamping, row deletion and calculated totals
- Daily call target and progress KPI cards
- Dark/light mode and sound toggle
- ExcelJS `.xlsx` report export with formatted summary and activity log
- Reset/new-day action

Data is stored in this browser's localStorage. It is not synced between devices or users.
