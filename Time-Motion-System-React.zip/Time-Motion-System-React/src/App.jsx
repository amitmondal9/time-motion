import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import ExcelJS from 'exceljs';

const ROW_KEY = 'tms_rows_amit';
const nowDot = () => { const d=new Date(); return `${d.getHours()%12||12}.${String(d.getMinutes()).padStart(2,'0')}`; };
const pad = n => String(n).padStart(2,'0');
const clockHours = mins => { mins=Math.max(0,parseInt(mins,10)||0); return `${Math.floor(mins/60)}.${pad(mins%60)}`; };
const cleanTime = value => {
  if (!value) return {valid:true,value:''};
  let s=String(value).trim().replace(':','.');
  if (/^\d{3,4}$/.test(s)) s=s.length===3 ? `${s[0]}.${s.slice(1)}` : `${s.slice(0,2)}.${s.slice(2)}`;
  const parts=s.split('.');
  const h=parseInt(parts[0],10);
  if (parts.length===1) return h>=1&&h<=12 ? {valid:true,value:String(h)} : {valid:false,value:s};
  let mstr=parts[1]; if(mstr.length===1)mstr+='0';
  const m=parseInt(mstr,10);
  if(!Number.isFinite(h)||h<1||h>12||!Number.isFinite(m)||m<0||m>=60)return {valid:false,value:s};
  return {valid:true,value:`${h}.${pad(m)}`};
};
const toMinutes = value => {
  if(!value)return null; const c=cleanTime(value); if(!c.valid||!c.value)return null;
  const [h,m='0']=c.value.split('.'); return Number(h)*60+Number(m);
};
const duration = (from,to) => {const a=toMinutes(from),b=toMinutes(to);if(a===null||b===null)return 0;let d=b-a;if(d<0)d+=720;return d;};
const ordinalDate = d => {const n=d.getDate(),suffix=n%10===1&&n!==11?'ST':n%10===2&&n!==12?'ND':n%10===3&&n!==13?'RD':'TH';return `${d.toLocaleString('en-US',{month:'short'}).toUpperCase()} ${n}${suffix}`;};
const makeRow = (activity,from,to='',mins=0) => ({id:`row_${Date.now()}_${Math.random().toString(36).slice(2,6)}`,activity,from,to,contactedCalls:0,contactedTime:0,nonContactCalls:0,nonContactTime:0,inMins:mins});
const isCalling = row => /call|adhoc/i.test(row?.activity||'');
const getStored = (key,fallback) => {try{const v=localStorage.getItem(key);return v===null?fallback:JSON.parse(v)}catch{return fallback}};
const btn = 'px-3 py-2 rounded-xl border font-semibold text-xs flex items-center gap-1.5 transition active:scale-95 shadow-sm';
const field = 'w-full bg-transparent border-0 focus:ring-1 focus:ring-blue-500 rounded px-1.5 py-1 text-slate-800 dark:text-slate-100 text-xs';
const timeField = 'w-16 text-center font-mono-num font-bold text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded px-1 py-1 focus:ring-1 focus:ring-blue-500';

export default function App(){
  const [rows,setRows]=useState(()=>getStored(ROW_KEY,[]));
  const [target,setTarget]=useState(()=>Number(localStorage.getItem('tms_target'))||160);
  const [empName,setEmpName]=useState(()=>localStorage.getItem('tms_emp_name')||'');
  const [empId,setEmpId]=useState(()=>localStorage.getItem('tms_emp_id')||'');
  const [sound,setSound]=useState(true);
  const [dark,setDark]=useState(()=>localStorage.getItem('tms_dark')==='true');
  const [now,setNow]=useState(Date.now());
  const [breakEnd,setBreakEnd]=useState(0);
  const audioRef=useRef(null);

  useEffect(()=>{localStorage.setItem(ROW_KEY,JSON.stringify(rows));},[rows]);
  useEffect(()=>{localStorage.setItem('tms_target',String(target));},[target]);
  useEffect(()=>{localStorage.setItem('tms_emp_name',empName);},[empName]);
  useEffect(()=>{localStorage.setItem('tms_emp_id',empId);},[empId]);
  useEffect(()=>{document.documentElement.classList.toggle('dark',dark);localStorage.setItem('tms_dark',String(dark));},[dark]);
  useEffect(()=>{const id=setInterval(()=>setNow(Date.now()),1000);return()=>clearInterval(id);},[]);
  useEffect(()=>{if(!breakEnd)return;const id=setInterval(()=>{if(Date.now()>=breakEnd){setBreakEnd(0);playChime(true);alert('⏰ Break time is completed! Return to your shift.');}},500);return()=>clearInterval(id);},[breakEnd]);
  useEffect(()=>{const active=rows.at(-1);if(active&&!active.to&&!localStorage.getItem('tms_active_start_timestamp'))localStorage.setItem('tms_active_start_timestamp',String(Date.now()));if(!active||active.to)localStorage.removeItem('tms_active_start_timestamp');},[rows]);

  const playTone=useCallback((freqs=[600],type='sine',durationSec=.08)=>{if(!sound)return;try{const Ctx=window.AudioContext||window.webkitAudioContext;if(!audioRef.current)audioRef.current=new Ctx();const ctx=audioRef.current;if(ctx.state==='suspended')ctx.resume();const t=ctx.currentTime;freqs.forEach((f,i)=>{const o=ctx.createOscillator(),g=ctx.createGain();o.type=type;o.frequency.setValueAtTime(f,t+i*.08);g.gain.setValueAtTime(.13,t+i*.08);g.gain.exponentialRampToValueAtTime(.001,t+i*.08+durationSec);o.connect(g);g.connect(ctx.destination);o.start(t+i*.08);o.stop(t+i*.08+durationSec);});}catch{}},[sound]);
  const playChime=(alertTone=false)=>playTone(alertTone?[587.33,880,1174.66]:[523.25,659.25],alertTone?'sine':'triangle',alertTone?1.2:.25);
  const totals=useMemo(()=>rows.reduce((a,r)=>({connected:a.connected+(+r.contactedCalls||0),connectedTime:a.connectedTime+(+r.contactedTime||0),non:a.non+(+r.nonContactCalls||0),nonTime:a.nonTime+(+r.nonContactTime||0),mins:a.mins+(+r.inMins||0)}),{connected:0,connectedTime:0,non:0,nonTime:0,mins:0}),[rows]);
  const totalCalls=totals.connected+totals.non, callMins=totals.connectedTime+totals.nonTime;
  const percent=target>0?totalCalls/target*100:0;
  const latest=rows.at(-1), active=!!latest&&!latest.to;
  const activeStart=Number(localStorage.getItem('tms_active_start_timestamp'))||now;
  const elapsed=active?Math.max(0,Math.floor((now-activeStart)/1000)):0;
  const timerText=`${pad(Math.floor(elapsed/3600))}:${pad(Math.floor(elapsed%3600/60))}:${pad(elapsed%60)}`;
  const timeText=new Date(now).toLocaleTimeString('en-US');
  const dateText=new Date(now).toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric'});
  const updateRow=(id,patch)=>setRows(old=>old.map(r=>r.id===id?{...r,...patch}:r));
  const startActivity=(name)=>{
    playTone();
    if(name==='Customer Calls & Adhoc Activity'&&isCalling(latest)&&active)return;
    setRows(old=>{const next=[...old];let from=nowDot();if(next.length){const last=next[next.length-1];if(!last.to){last.to=nowDot();last.inMins=duration(last.from,last.to);}from=last.to||from;}next.push(makeRow(name,from));return next;});
    localStorage.setItem('tms_active_start_timestamp',String(Date.now()));
  };
  const autoBreak=(mins,label='Break')=>{
    playChime();setRows(old=>{const next=[...old];let from=nowDot();if(next.length){const last=next.at(-1);if(!last.to){last.to=nowDot();last.inMins=duration(last.from,last.to);}from=last.to||from;}const start=toMinutes(from)||0,end=(start+mins)%720;const h=Math.floor(end/60)||12,m=end%60;next.push(makeRow(label,from,`${h}.${pad(m)}`,mins));return next;});
    setBreakEnd(Date.now()+mins*60000);
  };
  const punch=(type,amount)=>{if(!isCalling(latest))return;playTone();updateRow(latest.id,type==='contacted'?{contactedCalls:Math.max(0,(+latest.contactedCalls||0)+amount),contactedTime:Math.max(0,(+latest.contactedCalls||0)+amount)*3}:{nonContactCalls:Math.max(0,(+latest.nonContactCalls||0)+amount),nonContactTime:Math.max(0,(+latest.nonContactCalls||0)+amount)*2});};
  const stamp=(id,field)=>{playTone();const r=rows.find(x=>x.id===id);if(!r)return;const value=nowDot();const patch={[field]:value};const from=field==='from'?value:r.from,to=field==='to'?value:r.to;if(from&&to)patch.inMins=duration(from,to);updateRow(id,patch);if(id===latest?.id&&field==='to')localStorage.removeItem('tms_active_start_timestamp');};
  const changeCell=(r,field,value)=>{
    let patch={[field]:value};
    if(field==='from'||field==='to'){const c=cleanTime(value);patch[field]=c.value;const from=field==='from'?c.value:r.from,to=field==='to'?c.value:r.to;if(c.valid&&from&&to)patch.inMins=duration(from,to);}
    if(field==='contactedCalls'){const n=Math.max(0,parseInt(value,10)||0);patch={contactedCalls:n,contactedTime:n*3};}
    if(field==='nonContactCalls'){const n=Math.max(0,parseInt(value,10)||0);patch={nonContactCalls:n,nonContactTime:n*2};}
    if(['contactedTime','nonContactTime','inMins'].includes(field))patch[field]=Math.max(0,parseInt(value,10)||0);
    updateRow(r.id,patch);
  };
  const editTarget=()=>{const value=prompt('Enter Daily Calls Target:',target);if(value!==null){const n=parseInt(value,10);if(Number.isFinite(n)&&n>0)setTarget(n);}};
  const reset=()=>{if(confirm('Are you sure you want to clear the table and start a new day? Please ensure you have downloaded your TMS Report first!')){setRows([]);localStorage.removeItem('tms_active_start_timestamp');setBreakEnd(0);}};
  const exportExcel=async()=>{
    playTone();const name=(empName||'USER').trim().toUpperCase(),id=empId.trim().toUpperCase(),today=new Date();
    const wb=new ExcelJS.Workbook();wb.creator=name;wb.created=today;
    const sh=wb.addWorksheet('TMS Report',{views:[{showGridLines:true}]});
    sh.columns=[34,14,14,16,14,16,14,14,14].map((width,i)=>({key:`col${i}`,width}));
    const border={top:{style:'thin',color:{argb:'FF808080'}},left:{style:'thin',color:{argb:'FF808080'}},bottom:{style:'thin',color:{argb:'FF808080'}},right:{style:'thin',color:{argb:'FF808080'}}};
    const fill=argb=>({type:'pattern',pattern:'solid',fgColor:{argb}});
    const gray=fill('FFD9D9D9'),green=fill('FFA9D08E'),peach=fill('FFF8CBAD'),yellow=fill('FFFFFF00'),amber=fill('FFFFC000'),blue=fill('FF2563EB'),softBlue=fill('FFEFF6FF');
    const headline=`Daily Time Motion Study (TMS) - ${name} _ ${ordinalDate(today)}`;
    sh.addRow([headline]);sh.mergeCells('A1:I1');Object.assign(sh.getCell('A1'),{fill:blue,font:{bold:true,size:13,color:{argb:'FFFFFFFF'}},alignment:{vertical:'middle',horizontal:'center'}});sh.getRow(1).height=30;
    const headers=[id?`Emp ID: ${id}`:'Employee ID','Daily Target','Total Calls Done','Calls Left','Target %','Total Call Time','Shift Duration','Connected Calls','Non-Connect'];
    const values=[name,target,totalCalls,Math.max(0,target-totalCalls),`${percent.toFixed(2)}%`,`${clockHours(callMins)} hrs`,`${clockHours(totals.mins)} hrs (${totals.mins}m)`,totals.connected,totals.non];
    [headers,values].forEach((arr,i)=>{const row=sh.addRow(arr);row.height=i?24:20;row.eachCell(c=>{c.fill=i?softBlue:gray;c.font={bold:true,size:i?11:10,color:{argb:i?'FF1E3A8A':'FF000000'}};c.alignment={vertical:'middle',horizontal:'center'};c.border=border;});});
    sh.addRow([]);
    sh.addRow(['Customer Calls & Adhoc Activity','Time','','Connected','','Non-Connect','','Total Time','']);
    sh.addRow(['','From','To','Allowed - 3 Mins','Time Taken','Allowed - 2 Mins','Time Taken','In Mins','In Hours']);
    sh.mergeCells('A5:A6');sh.mergeCells('B5:C5');sh.mergeCells('D5:E5');sh.mergeCells('F5:G5');sh.mergeCells('H5:I5');
    ['A5','B5','C5','H5','I5','B6','C6','H6','I6'].forEach(k=>{const c=sh.getCell(k);c.fill=gray;c.font={bold:true};c.alignment={vertical:'middle',horizontal:'center'};c.border=border;});
    ['D5','E5','D6','E6'].forEach(k=>{const c=sh.getCell(k);c.fill=green;c.font={bold:true};c.alignment={vertical:'middle',horizontal:'center'};c.border=border;});
    ['F5','G5','F6','G6'].forEach(k=>{const c=sh.getCell(k);c.fill=peach;c.font={bold:true};c.alignment={vertical:'middle',horizontal:'center'};c.border=border;});
    rows.forEach(r=>{const row=sh.addRow([r.activity||'',r.from||'',r.to||'',r.contactedCalls||'',r.contactedTime||'',r.nonContactCalls||'',r.nonContactTime||'',r.inMins||'',r.inMins?clockHours(r.inMins):'']);row.eachCell((c,i)=>{c.font={size:11};c.border=border;c.alignment={vertical:'middle',horizontal:i===1?'left':'center'};});});
    const total=sh.addRow(['Total','','',totals.connected,totals.connectedTime,totals.non,totals.nonTime,totals.mins,clockHours(totals.mins)]);
    total.eachCell((c,i)=>{c.font={bold:true};c.border=border;c.alignment={vertical:'middle',horizontal:'center'};if([4,6,8,9].includes(i))c.fill=yellow;else if([5,7].includes(i))c.fill=amber;});
    const buffer=await wb.xlsx.writeBuffer(),blob=new Blob([buffer],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}),url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download=`TMS_Report_${name.replace(/[^A-Z0-9]/gi,'_')}_${today.toISOString().slice(0,10)}.xlsx`;a.click();URL.revokeObjectURL(url);
  };
  const activityButtons=[
    ['🎧','Calling & Adhoc','Customer Calls & Adhoc Activity','indigo'],
    ['🌅','Morning Meeting','Morning Metting','amber'],
    ['👥','Meeting','Metting','teal'],
    ['🍱','Lunch','Lunch','orange'],
    ['☕','Break','Break','yellow'],
    ['⚡','Power Cut','Power Cut / Electricity Off','amber'],
    ['💻','System Down','System Down / IT Issue','red'],
    ['🩺','Medical Issue','Medical Emergency','purple']
  ];
  const colorClass={indigo:'border-indigo-200 bg-indigo-50/70 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300',amber:'border-amber-200 bg-amber-50/70 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300',teal:'border-teal-200 bg-teal-50/70 text-teal-700 dark:bg-teal-950/40 dark:text-teal-300',orange:'border-orange-200 bg-orange-50/70 text-orange-700 dark:bg-orange-950/40 dark:text-orange-300',yellow:'border-yellow-300 bg-yellow-50/80 text-yellow-800 dark:bg-yellow-950/40 dark:text-yellow-300',red:'border-red-300 bg-red-50/70 text-red-800 dark:bg-red-950/30 dark:text-red-300',purple:'border-purple-300 bg-purple-50/70 text-purple-800 dark:bg-purple-950/30 dark:text-purple-300'};
  const th='p-2 text-center font-bold text-slate-800 dark:text-slate-900';
  return <main className="min-h-screen bg-slate-100 text-slate-800 dark:bg-slate-950 dark:text-slate-100 transition-colors duration-200 p-3 sm:p-5">
    <div className="max-w-[1540px] mx-auto space-y-4">
      <header className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3"><div className="w-11 h-11 rounded-xl bg-blue-600 text-white flex items-center justify-center text-2xl">◷</div><div><div className="flex items-center gap-2 flex-wrap"><h1 className="text-xl sm:text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white">Time Motion System</h1><span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">● Shift Active</span></div><p className="text-xs text-slate-500 dark:text-slate-400 font-medium">{dateText}</p></div></div>
        <div className="flex flex-wrap items-center gap-2 bg-slate-50 dark:bg-slate-800/60 p-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
          <label className="flex items-center gap-1.5 px-2"><span className="text-slate-500 font-semibold uppercase text-[10px]">Emp:</span><input value={empName} onChange={e=>setEmpName(e.target.value)} placeholder="Enter Full Name" className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-2.5 py-1 w-36 sm:w-44 font-bold"/></label>
          <span className="h-5 w-px bg-slate-300 dark:bg-slate-700"/>
          <label className="flex items-center gap-1.5 px-2"><span className="text-slate-500 font-semibold uppercase text-[10px]">ID:</span><input value={empId} onChange={e=>setEmpId(e.target.value)} placeholder="Emp ID" className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-2.5 py-1 w-20 sm:w-28 font-bold uppercase"/></label>
        </div>
        <div className="flex items-center gap-3"><div className="bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-900/60 px-4 py-2 rounded-xl text-center"><span className="block text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">Current Time</span><span className="text-lg sm:text-xl font-bold font-mono-num text-blue-700 dark:text-blue-300">{timeText}</span></div><button onClick={()=>{setSound(v=>!v);if(!sound)playTone();}} title="Sound alert toggle" className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-800">{sound?'🔊':'🔇'}</button><button onClick={()=>setDark(v=>!v)} title="Toggle dark mode" className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-800">{dark?'☀️':'🌙'}</button></div>
      </header>

      <section className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
        <Kpi title="Target" value={target} note="Daily calls goal" action={<button onClick={editTarget} className="text-blue-600 text-xs font-semibold">Change ✎</button>}/>
        <Kpi title="Total Calls" value={totalCalls} color="blue" note={<><span>Time: {clockHours(callMins)} hrs</span><span className="text-amber-600">{Math.max(0,target-totalCalls)} left</span></>}/>
        <Kpi title="Connected" value={totals.connected} color="green" note={`Time: ${totals.connectedTime}m`}/>
        <Kpi title="Non-Connect" value={totals.non} color="red" note={`Time: ${totals.nonTime}m`}/>
        <div className="col-span-2 md:col-span-1 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm"><div className="flex justify-between text-xs font-semibold text-slate-500 uppercase"><span>Target Progress</span><span className={percent>=100?'text-emerald-600':percent>=50?'text-amber-500':'text-rose-600'}>{percent.toFixed(2)}%</span></div><div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden my-3"><div className={`h-full rounded-full ${percent>=100?'bg-emerald-500':percent>=50?'bg-amber-500':'bg-rose-500'}`} style={{width:`${Math.min(100,percent)}%`}}/></div><div className="text-xs font-semibold font-mono-num text-slate-500">Target: <b className="text-blue-600">{totalCalls}</b> / {target}</div></div>
      </section>

      <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-4 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800"><div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-ping"/><h2 className="text-base font-bold text-slate-900 dark:text-white">Activity Section</h2><span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800">{active?latest.activity:'Idle'}</span></div><div className="flex items-center gap-2 text-xs text-slate-500">Running Timer: <span className="px-3 py-1 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 font-mono-num font-bold rounded-lg text-sm">{timerText}</span></div></div>
        <div className="flex flex-wrap items-center justify-between gap-3"><div className="flex flex-wrap items-center gap-2"><span className="text-xs font-bold text-slate-500 uppercase mr-1">Work:</span>{activityButtons.slice(0,5).map(([emoji,label,value,color])=><button key={value} onClick={()=>startActivity(value)} className={`${btn} ${colorClass[color]}`}>{emoji} {label}{value==='Customer Calls & Adhoc Activity'&&active&&isCalling(latest)?' ●':''}</button>)}</div><div className="flex flex-wrap items-center gap-1.5 bg-slate-50 dark:bg-slate-800/60 p-1.5 rounded-xl border border-slate-200 dark:border-slate-800"><span className="text-xs font-bold text-amber-700 px-2">☕ AUTO BREAK:</span>{[10,15,20].map(n=><button key={n} onClick={()=>autoBreak(n)} className="px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-semibold">☕ {n}m</button>)}<button onClick={()=>autoBreak(45,'Lunch')} className="px-3 py-1.5 rounded-lg bg-amber-500 text-white font-bold text-xs">🍱 45m Lunch</button></div></div>
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-slate-800"><div className="flex flex-wrap items-center gap-2"><span className="text-xs font-bold text-rose-500 uppercase">⚠️ Downtime:</span>{activityButtons.slice(5).map(([emoji,label,value,color])=><button key={value} onClick={()=>startActivity(value)} className={`${btn} ${colorClass[color]}`}>{emoji} {label}</button>)}</div><div className="flex flex-wrap items-center gap-3">
          <Puncher color="green" label="Connected" count={totals.connected} onMinus={()=>punch('contacted',-1)} onOne={()=>punch('contacted',1)} onFive={()=>punch('contacted',5)} disabled={!isCalling(latest)}/>
          <Puncher color="red" label="Non-Connect" count={totals.non} onMinus={()=>punch('nonContact',-1)} onOne={()=>punch('nonContact',1)} onFive={()=>punch('nonContact',5)} disabled={!isCalling(latest)}/>
        </div></div>
        {breakEnd>0&&<p className="text-xs text-amber-700 font-semibold">Break countdown: {pad(Math.floor(Math.max(0,breakEnd-now)/60000))}:{pad(Math.floor(Math.max(0,breakEnd-now)%60000/1000))}</p>}
      </section>

      <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3"><div className="flex items-center gap-3"><div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-600 flex items-center justify-center">▤</div><h3 className="text-base font-extrabold text-slate-900 dark:text-white">Customer Calls & Adhoc Activity Table</h3></div><div className="flex flex-wrap items-center gap-2"><button onClick={exportExcel} className="px-3.5 py-1.5 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white">⇩ Download</button><button onClick={reset} className="px-3 py-1.5 text-xs font-semibold rounded-xl border border-rose-300 text-rose-600 hover:bg-rose-50">Reset / New Day</button></div></div>
        <div className="overflow-x-auto"><table className="w-full text-center border-collapse excel-table text-xs min-w-[1050px]"><thead><tr className="font-bold text-slate-800"><th rowSpan="2" className={`${th} bg-tmsGray min-w-[220px] text-left text-[13px]`}>Customer Calls & Adhoc Activity</th><th colSpan="2" className={`${th} bg-tmsGray text-[13px]`}>Time</th><th colSpan="2" className={`${th} bg-tmsGreen text-[13px]`}>Connected</th><th colSpan="2" className={`${th} bg-tmsPeach text-[13px]`}>Non-Connect</th><th colSpan="2" className={`${th} bg-tmsGray text-[13px]`}>Total Time</th><th rowSpan="2" className={`${th} bg-slate-200 min-w-[65px]`}>Action</th></tr><tr className="font-semibold text-slate-800 text-[11px]"><th className="bg-slate-100 p-1.5 min-w-[95px]">From</th><th className="bg-slate-100 p-1.5 min-w-[95px]">To</th><th className="bg-emerald-100/80 p-1.5 min-w-[90px]">Allowed - 3 Mins</th><th className="bg-emerald-100/80 p-1.5 min-w-[80px]">Time Taken</th><th className="bg-rose-100/80 p-1.5 min-w-[90px]">Allowed - 2 Mins</th><th className="bg-rose-100/80 p-1.5 min-w-[80px]">Time Taken</th><th className="bg-slate-100 p-1.5 min-w-[75px]">In Mins</th><th className="bg-slate-100 p-1.5 min-w-[75px]">In Hours</th></tr></thead>
          <tbody className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100">{rows.map(r=><tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50"><td className="p-1.5 text-left"><input value={r.activity} onChange={e=>changeCell(r,'activity',e.target.value)} className={`${field} font-semibold`}/></td>
            <TimeCell value={r.from} placeholder="9.30" onChange={v=>changeCell(r,'from',v)} onStamp={()=>stamp(r.id,'from')}/>
            <TimeCell value={r.to} placeholder="10.15" onChange={v=>changeCell(r,'to',v)} onStamp={()=>stamp(r.id,'to')}/>
            <td className="p-1"><input type="number" value={r.contactedCalls} onChange={e=>changeCell(r,'contactedCalls',e.target.value)} className={`${timeField} w-16`}/></td>
            <td className="p-1"><input type="number" value={r.contactedTime} onChange={e=>changeCell(r,'contactedTime',e.target.value)} className={`${timeField} w-16`}/></td>
            <td className="p-1"><input type="number" value={r.nonContactCalls} onChange={e=>changeCell(r,'nonContactCalls',e.target.value)} className={`${timeField} w-16`}/></td>
            <td className="p-1"><input type="number" value={r.nonContactTime} onChange={e=>changeCell(r,'nonContactTime',e.target.value)} className={`${timeField} w-16`}/></td>
            <td className="p-1"><input type="number" value={r.inMins} onChange={e=>changeCell(r,'inMins',e.target.value)} className={`${timeField} w-16`}/></td>
            <td id={`hrs_${r.id}`} className="p-1 font-mono-num font-bold">{r.inMins?clockHours(r.inMins):''}</td><td className="p-1"><button onClick={()=>{playTone();setRows(old=>old.filter(x=>x.id!==r.id));}} className="text-rose-500 hover:text-rose-700 font-bold px-2 py-1">Delete</button></td></tr>)}</tbody>
          <tfoot className="font-bold text-slate-900 text-[13px]"><tr><td className="p-2.5 text-center bg-white dark:bg-slate-900 dark:text-white">Total</td><td className="bg-white dark:bg-slate-900"/><td className="bg-white dark:bg-slate-900"/><td className="p-2 bg-tmsYellow text-slate-950">{totals.connected}</td><td className="p-2 bg-tmsAmber text-slate-950">{totals.connectedTime}</td><td className="p-2 bg-tmsYellow text-slate-950">{totals.non}</td><td className="p-2 bg-tmsAmber text-slate-950">{totals.nonTime}</td><td className="p-2 bg-tmsYellow text-slate-950">{totals.mins}</td><td className="p-2 bg-tmsYellow text-slate-950">{clockHours(totals.mins)}</td><td className="bg-slate-100 dark:bg-slate-800"/></tr></tfoot></table></div>
        {!rows.length&&<div className="text-center py-10 px-4 text-slate-400"><div className="text-4xl mb-2">▤</div><p className="text-sm font-medium">Table is completely blank. Click any activity button above to add your first task!</p></div>}
      </section>
      <footer className="text-center py-4 text-xs text-slate-500 flex flex-col items-center gap-1"><p className="font-semibold text-slate-600 dark:text-slate-400">Time Motion System (TMS)</p><p className="text-[11px] tracking-wide text-slate-400 opacity-50">Create by Amit Mondal</p></footer>
    </div>
  </main>;
}

function Kpi({title,value,color='slate',note,action}){const styles={slate:'text-slate-900 dark:text-white',blue:'text-blue-600 dark:text-blue-400',green:'text-emerald-700 dark:text-emerald-400',red:'text-rose-600 dark:text-rose-400'};return <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between min-h-[118px]"><div className="flex items-center justify-between"><span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{title}</span>{action}</div><div className={`mt-2 text-2xl sm:text-3xl font-extrabold font-mono-num ${styles[color]}`}>{value}</div><div className="mt-2 flex items-center justify-between gap-2 text-[11px] font-mono-num font-semibold text-slate-500">{note}</div></div>}
function Puncher({color,label,count,onMinus,onOne,onFive,disabled}){const green=color==='green';return <div className={`flex items-center gap-1 p-1 rounded-xl border text-xs ${green?'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/60':'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800/60'} ${disabled?'opacity-50':''}`}><span className={`font-bold px-2 ${green?'text-emerald-800 dark:text-emerald-300':'text-rose-800 dark:text-rose-300'}`}>{count} {label}:</span><button disabled={disabled} onClick={onMinus} className="w-7 h-7 rounded-lg bg-white dark:bg-slate-900 border font-bold disabled:cursor-not-allowed">-</button><button disabled={disabled} onClick={onOne} className={`px-2 h-7 rounded-lg text-white font-bold disabled:cursor-not-allowed ${green?'bg-emerald-600':'bg-rose-600'}`}>+1</button><button disabled={disabled} onClick={onFive} className={`px-2 h-7 rounded-lg text-white font-bold disabled:cursor-not-allowed ${green?'bg-emerald-700':'bg-rose-700'}`}>+5</button></div>}
function TimeCell({value,placeholder,onChange,onStamp}){return <td className="p-1"><div className="flex items-center gap-1 justify-center"><input value={value||''} placeholder={placeholder} onChange={e=>onChange(e.target.value)} onBlur={e=>{const c=cleanTime(e.target.value);if(c.valid)onChange(c.value);}} className={timeField}/><button onClick={onStamp} title="Stamp current time" className="text-slate-400 hover:text-blue-600">◷</button></div></td>}
